package com.democo.jersey.film.controllers;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.democo.jersey.film.dao.FilmDao;
import com.democo.jersey.film.model.Film;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;

/**
 * Servlet implementation class FilmApi
 */
@WebServlet("/filmapi")
public class FilmApi extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private FilmDao filmDao = new FilmDao();

//maps the the servlet to the specified URL pattern, which in this case is the "/filmapi"
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public FilmApi() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
	        throws ServletException, IOException {
	    String format = request.getParameter("format");

	    // If format is null, set the default format to JSON
	    if (format == null) {
	        format = "json";
	    }

	    // Set the content type based on the selected format
	    if (format.equals("json")) {
	        response.setContentType("application/json");
	    } else if (format.equals("xml")) {
	        response.setContentType("application/xml");
	    } else if (format.equals("text")) {
	        response.setContentType("text/plain");
	    }

	    List<Film> allfilms = null;
	    try {
	        allfilms = filmDao.getAllFilms();
	    } catch (SQLException e1) {
	        throw new ServletException("Error getting film list", e1);
	    }
	    request.setAttribute("films", allfilms);
	    request.getRequestDispatcher("films.jsp").forward(request, response);

	    if (format != null && format.equals("xml")) {
	        // Handle XML format
	        // ...
	    } else if (format != null && format.equals("json")) {
	        // Handle JSON format
	        // ...
	    } else {
	        // Handle text format
	        // ...
	    }
	}


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// Retrieve request data (parameters or body)
		// int id = Integer.parseInt(request.getParameter("id"));
		String title = request.getParameter("title");
		int year = Integer.parseInt(request.getParameter("year"));
		String director = request.getParameter("director");
		String stars = request.getParameter("stars");
		String review = request.getParameter("review");

		// Create java film object
		Film film = new Film(0, title, year, director, stars, review);

		// Insert new film to database
		try {
			filmDao.insertFilm(film);
		} catch (SQLException e) {
			// Handle the SQL Exception
			response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Database error: " + e.getMessage());
			return;
		}

		// Create the response object
		JsonObject responseObject = new JsonObject();
		responseObject.addProperty("success", true);
		responseObject.addProperty("message", "Film added successfully");

		// Set the response content type and output the response in JSON format
		response.setContentType("application/json");
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		response.getWriter().print(gson.toJson(responseObject));

		// Redirect back to the index page
		response.sendRedirect(request.getContextPath() + "/");
	}

	protected void doPut(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));

		// Retrieve other request data (parameters or body)
		String title = request.getParameter("title");
		int year = Integer.parseInt(request.getParameter("year"));
		String director = request.getParameter("director");
		String stars = request.getParameter("stars");
		String review = request.getParameter("review");

		// Create java film object
		Film film = new Film(id, title, year, director, stars, review);

		filmDao.updateFilm(film);

		// Create the response object
		JsonObject responseObject = new JsonObject();
		responseObject.addProperty("success", true);
		responseObject.addProperty("message", "Film updated successfully");

		// Set the response content type and output the response in JSON format
		response.setContentType("application/json");
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		response.getWriter().print(gson.toJson(responseObject));

		// Redirect back to the index page
		response.sendRedirect(request.getContextPath() + "/");
	}

	@Override
	protected void doDelete(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// Parse the id parameter from the request
		String idParam = request.getParameter("id");
		if (idParam == null) {
			response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
			response.getWriter().println("Missing id parameter");
			return;
		}
		int id;
		try {
			id = Integer.parseInt(idParam);
		} catch (NumberFormatException e) {
			response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
			response.getWriter().println("Invalid id parameter: " + idParam);
			return;
		}

		// Delete the film by ID
		try {
			filmDao.deleteFilm(id);
		} catch (SQLException e) {
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			response.getWriter().println("Database error: " + e.getMessage());
			return;
		}

		// Return a success response
		response.setStatus(HttpServletResponse.SC_OK);
		response.getWriter().println("Film with ID " + id + " has been deleted.");

		// Redirect back to the index page
		response.sendRedirect(request.getContextPath() + "/");
	}

}
