package com.democo.jersey.film.dao;

import java.util.ArrayList;
import java.util.List;
import java.sql.*;
import com.democo.jersey.film.model.Film;

public class FilmDao {

	public static Object instance;
	Film oneFilm = null;
	Connection conn = null;
	Statement stmt = null;
	String user = "osarobod";
	String password = "losquarL2";
	// Note none default port used, 6306 not 3306
	String url = "jdbc:mysql://mudfoot.doc.stu.mmu.ac.uk:6306/" + user;

	public FilmDao() {
	}

//Method to open a connection to the database 
	private void openConnection() throws SQLException {
		// loading JDBC driver for MySQL
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
		} catch (Exception e) {
			// Exception thrown if the JDBC driver can't be loaded
			System.out.println(e);
		}

		// connecting to database
		try {
			// Connection string for database, with username and password
			conn = DriverManager.getConnection(url, user, password);
		} catch (SQLException se) {
			// Exception thrown if connection to database can't be established
			System.out.println(se);
		}
	}

	// Method to close the connection to the database
	private void closeConnection() throws SQLException {
		try { // The try-catch block catches any SQLException that might occur,
				// while trying to close the connection and prints the stack trace of the
				// exception
			conn.close();
		} catch (SQLException e) {
			// Exception thrown if error occurs while closing the connection
			e.printStackTrace();
		}
	}

	// Method to get the next film from the result set
	private Film getNextFilm(ResultSet rs) {
		Film thisFilm = null;
		try {
			// Create new film object from the current row of the result set
			thisFilm = new Film(rs.getInt("id"), rs.getString("title"), rs.getInt("year"), rs.getString("director"),
					rs.getString("stars"), rs.getString("review"));
		} catch (SQLException e) {
			// Exception thrown if error occurs while retrieving the film data
			e.printStackTrace();
		}
		return thisFilm;
	}

	// Method to get all films from the database
	public ArrayList<Film> getAllFilms() throws SQLException {

		ArrayList<Film> allFilms = new ArrayList<Film>();
		openConnection();

		// Create select statement and execute it
		try {
			String selectSQL = "select * from films";
			PreparedStatement preparedStatement = conn.prepareStatement(selectSQL);
			ResultSet rs1 = preparedStatement.executeQuery(selectSQL);
			// Retrieve the results
			while (rs1.next()) {
				oneFilm = getNextFilm(rs1);
				allFilms.add(oneFilm);
			}

			preparedStatement.close();
			closeConnection();
		} catch (SQLException se) {
			// Exception thrown if error occurs while executing the query
			System.out.println(se);
		}

		return allFilms;
	}

	// Method to get a film by its id
	public Film getFilmByID(int id) throws SQLException {
	    openConnection();
	    Film oneFilm = null;
	    try {
	        String selectSQL = "select * from films where id=?";
	        PreparedStatement preparedStatement = conn.prepareStatement(selectSQL);
	        preparedStatement.setInt(1, id);
	        ResultSet rs = preparedStatement.executeQuery();
	        if (rs.next()) {
	            oneFilm = getNextFilm(rs);
	        }
	        preparedStatement.close();
	        closeConnection();
	    } catch (SQLException se) {
	        System.out.println(se);
	    }
	    return oneFilm;
	}

	// Method to get a Film by it's Title
	public Film getFilmByTitle(String title) throws SQLException {
		openConnection();
		oneFilm = null;
		// Create select statement and execute it
		try {
			String selectSQL = "select * from films where title = ?";
			PreparedStatement preparedStatement = conn.prepareStatement(selectSQL);
			preparedStatement.setString(1, title);
			ResultSet rs1 = preparedStatement.executeQuery();
			// Retrieve the results
			while (rs1.next()) {
				oneFilm = getNextFilm(rs1);
			}
			preparedStatement.close();
			closeConnection();
		} catch (SQLException se) {
			// Exception thrown if error occurs while executing the query
			System.out.println(se);
		}

		return oneFilm;
	}

	// Method to insert a Film into the database
	public void insertFilm(Film film) throws SQLException {
	    openConnection();
	    String insertSQL = "INSERT INTO films (title, year, director, stars, review) VALUES (?, ?, ?, ?, ?)";
	    try (PreparedStatement preparedStatement = conn.prepareStatement(insertSQL)) {
	        preparedStatement.setString(1, film.getTitle());
	        preparedStatement.setInt(2, film.getYear());
	        preparedStatement.setString(3, film.getDirector());
	        preparedStatement.setString(4, film.getStars());
	        preparedStatement.setString(5, film.getReview());
	        preparedStatement.executeUpdate();
	        preparedStatement.close();
	       
	    } catch (SQLException se) {
	        // Exception thrown if error occurs while executing the query
	        System.out.println(se);
	    } finally {
	    closeConnection();
	    
	    }
	}
   
	//Method to Update Film
	public int updateFilm(int id, Film film) throws SQLException {
	    openConnection();
	    String updateSQL = "UPDATE films SET title = ?, year = ?, director = ?, stars = ?, review = ?  WHERE id = ?";
	    try (PreparedStatement preparedStatement = conn.prepareStatement(updateSQL)) {
	        preparedStatement.setString(1, film.getTitle());
	        preparedStatement.setInt(2, film.getYear());
	        preparedStatement.setString(3, film.getDirector());
	        preparedStatement.setString(4, film.getStars());
	        preparedStatement.setString(5, film.getReview());
	        preparedStatement.setInt(6, id);
	        preparedStatement.executeUpdate();
	        preparedStatement.close();
	        closeConnection();
	    } catch (SQLException se) {
	        // Exception thrown if error occurs while executing the query
	        System.out.println(se);
	    }
	    closeConnection();
	    return 0;
	}

	

	// Method to delete Film
	public void deleteFilm(int id) throws SQLException {
		openConnection();
		String deleteSQL = "DELETE FROM films WHERE id = ?";
		try {
			PreparedStatement preparedStatement = conn.prepareStatement(deleteSQL);
			preparedStatement.setInt(1, id);
			preparedStatement.executeUpdate();
		} catch (SQLException se) {
			// Exception thrown if error occurs while executing the query
			System.out.println(se);
			// Exception thrown if error occurs while executing the query
		} finally { // best practice to
			closeConnection();
		}

	}

	// Method to Search Film.
	public ArrayList<Film> searchFilms(String searchStr) throws SQLException {
		openConnection();
		ArrayList<Film> films = new ArrayList<Film>();
		String selectSQL = "SELECT * FROM films WHERE title LIKE ? OR director LIKE ? OR stars LIKE ?";
		try (PreparedStatement preparedStatement = conn.prepareStatement(selectSQL)) {
			preparedStatement.setString(1, "%" + searchStr + "%");
			preparedStatement.setString(2, "%" + searchStr + "%");
			preparedStatement.setString(3, "%" + searchStr + "%");
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				// Retrieve the result
				films.add(getNextFilm(rs));
			}
		} catch (SQLException se) {
			// Exception thrown if error occurs while executing the query
			System.out.println(se);
		}
		closeConnection();
		// Exception thrown if error occurs while executing the query
		return films;
	}

	// Method to get Film directed by a director
	public List<Film> getFilmsByDirector(String director) throws SQLException {
		List<Film> films = new ArrayList<Film>();
		openConnection();
		// create a select statement and execute it.
		try {
			String selectSQL = "SELECT * FROM films WHERE director = ?";
			PreparedStatement preparedStatement = conn.prepareStatement(selectSQL);
			preparedStatement.setString(1, director);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				films.add(getNextFilm(rs));
			}

		} catch (SQLException se) {
			// Exception thrown if error occurs while executing the query
			System.out.println(se);
		}
		closeConnection();
		// Exception thrown if error occurs while executing the query
		return films;
	}

	// Method to get films by year
	public List<Film> getFilmsByYear(int year) throws SQLException {
		List<Film> films = new ArrayList<Film>();
		openConnection();
		// create a select statement and execute it
		try {
			String selectSQL = "select * from films where year=" + year;
			PreparedStatement prepareStatement = conn.prepareStatement(selectSQL);
			ResultSet rs = prepareStatement.executeQuery(selectSQL);
			while (rs.next()) {
				films.add(getNextFilm(rs));
			}
		} catch (SQLException se) {
			// Exception thrown if error occurs while executing the query
			System.out.println(se);
		}
		closeConnection();
		// Exception thrown if error occurs while executing the query
		return films;
	}

	// Method to get Film by a certain Star
	public List<Film> getFilmsByStars(String stars) throws SQLException {
		List<Film> films = new ArrayList<>();
		openConnection();
		try {
			String selectSQL = "SELECT * FROM films WHERE stars LIKE ?";
			PreparedStatement prepareStatement = conn.prepareStatement(selectSQL);
			prepareStatement.setString(1, "%" + stars + "%");
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				// Retrieve the Result
				films.add(getNextFilm(rs));
			}
		} catch (SQLException e) {
			// Exception thrown if error occurs while executing the query
			e.printStackTrace();
		}
		closeConnection();
		// Exception thrown if error occurs while executing the query
		return films;
	}

	public void deleteFilm(Film film) {
		// TODO Auto-generated method stub

	}

	public ArrayList<Film> getFilm() {
		ArrayList<Film> filmList = null;
		return filmList;
	}

	@SuppressWarnings("null")
	public Film getFilm(int id) {
		Film[] filmList = null;
		for (Film film : filmList) {
			if (film.getId() == id) {
				return film;
			}
		}
		return null;
	}

	public int createFilm(Film film) {
		// TODO Auto-generated method stub
		return 0;
	}

	public void addFilm(Film film) {
		// method that adds a film to the database by taking a film object as an
		// argument

	}

	public void updateFilm(Film film) {
		// TODO Auto-generated method stub
		
	}

	public Film getFilmById(int id) throws SQLException{
		// implementation goes here
		return null;
	}

	
	}
