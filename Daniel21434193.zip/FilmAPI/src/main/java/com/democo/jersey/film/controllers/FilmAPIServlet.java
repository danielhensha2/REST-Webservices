package com.democo.jersey.film.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.democo.jersey.film.dao.FilmDao;
import com.democo.jersey.film.model.Film;

import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.Marshaller;

@WebServlet("/films")
public class FilmAPIServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private FilmDao filmDao = new FilmDao();

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String format = request.getParameter("format");
		response.setContentType("text/plain");

		List<Film> allfilms = null;
		try {
			allfilms = filmDao.getAllFilms();
		} catch (SQLException e1) {
			throw new ServletException("Error getting film list", e1);
		}

		if (format != null && format.equals("xml")) {
			response.setContentType("application/xml");
			try {
				JAXBContext context = JAXBContext.newInstance(Film.class);
				Marshaller marshaller = context.createMarshaller();
				marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
				Film filmList = new Film(allfilms);
				marshaller.marshal(filmList, response.getWriter());
			} catch (jakarta.xml.bind.JAXBException e) {
				throw new ServletException("Error marshalling film list", e);
			}
		} else if (format != null && format.equals("json")) {
//			response.setContentType("application/json");
//			//ObjectMapper mapper = new ObjectMapper();
//			mapper.configure(SerializationConfig.Feature.INDENT_OUTPUT, true);
//			mapper.writeValue(response.getWriter(), allfilms);
		} else {
			PrintWriter out = response.getWriter();
			for (Film film : allfilms) {
				out.println(film.toString());

			}

		}
	}
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// Retrieve request data (parameters or body)
	    int id  = Integer.parseInt(request.getParameter("id"));
	    String title = request.getParameter("title");
	    int year = Integer.parseInt(request.getParameter("year"));
	    String director = request.getParameter("director");
	    String stars = request.getParameter("stars");
	    String review = request.getParameter("review");

	    // Create java film object
	    Film film = new Film(id, title, year, director, stars, review);

	    // Insert new film to database
	    try {
	        filmDao.insertFilm(film);
	    } catch (SQLException e) {
	        // Handle the SQL Exception
	        response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Database error: " + e.getMessage());
	        return;
	    }

	    // Redirect to Home-page
	    response.sendRedirect(request.getContextPath() + "/");
	}
	

     

	@Override
	protected void doDelete(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		// Retrieve request data (parameters or body)
		int filmId = Integer.parseInt(request.getParameter("id"));
		try {
			// Delete Film from Database
			filmDao.deleteFilm(filmId);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		response.setStatus(HttpServletResponse.SC_NO_CONTENT);
	

	}
	


}





